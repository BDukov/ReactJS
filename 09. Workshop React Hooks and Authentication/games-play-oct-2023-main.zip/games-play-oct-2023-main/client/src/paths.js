const Path = {
    Home: '/',
    Logout: '/logout',
};

export default Path;
