import { createContext } from "react";

const AuthContext = createContext();

AuthContext.displayName = 'AuthContext';

export default AuthContext;
